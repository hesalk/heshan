document.getElementById("problem6abutton").addEventListener("click", myFunction);
function myFunction() {
  document.getElementById("txtjs").textContent = "Hello world";
}
