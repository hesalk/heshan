# Adder

Write a program that uses the function `prompt` to get two different numbers from the user. You'll then `alert` the sum of these two numbers.

This code needs to be run in a browser.
