# Hello World

Write a function `helloworld` that outputs the text "Hello world" in the console.

*Example*
```
helloworld()
// -> "Hello world"
```
