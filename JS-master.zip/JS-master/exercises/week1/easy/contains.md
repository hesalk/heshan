# Contains

Write a function `contains` that takes two arguments. The first should be an array, and the second one should be a value of any type.
The function should return whether the second argument exists inside the array.

**Example**

```
contains([1, 2, 3], 2) // -> true
contains(["dog", "cat"], "cat") // -> true
contains(["banana", "carrot"], "orange") // -> false
```
