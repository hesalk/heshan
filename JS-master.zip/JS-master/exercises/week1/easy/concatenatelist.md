# Concatenate lists

Write a function `concatenate` that takes two arrays as arguments.
The function should return the two arrays merged into a single array.

**Example**

```
concatenate([1, 2, 3], [4, 5, 6])
// -> [1, 2, 3, 4, 5, 6]
```
