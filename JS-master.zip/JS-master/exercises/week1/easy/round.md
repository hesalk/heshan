# Round

Write a function `round` that takes a number as argument. Return the number rounded to nearest whole number.

*Tip: use the Math object*

**Example**

```
round(2.5); // -> 3
round(2.1); // -> 2
round(2.7); // -> 3
```
