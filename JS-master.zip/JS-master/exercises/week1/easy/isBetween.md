# IsBetween

Write a function `isBetween` that takes three numbers as arguments. `x`, `from` and `to`. Return if `x` is between `from` and `to`.
