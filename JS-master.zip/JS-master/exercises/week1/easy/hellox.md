# Hello X

Write a function `hellox` that takes a string as argument `x`. Then output the text "Hello X" to the console where X is replaced with the argument `x`.

*Example*
```
hellox("Viktor")
// -> "Hello Viktor"
```
