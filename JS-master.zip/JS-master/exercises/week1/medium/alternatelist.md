# Alternate lists

Write a function `alternate` that combines two lists by alternatingly taking elements.

**Example**

```
alternate(['a', 'b', 'c'], [1, 2, 3])
// -> ['a', 1, 'b', 2, 'c', 3]
```
