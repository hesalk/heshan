# Reverse string

Write a function called `reverseString` that takes a string as input and returns the reversed value of it.

*Example* 
```
reverseString('Hello')
// -> 'olleH'
```
