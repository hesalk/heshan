# Longest Word

Write a function `longestWord` that takes a single string `word` as argument. Then return the word in the string that is the longest.

*Example*
```
longestWord("Hello Kate")
// -> "Hello"
```
