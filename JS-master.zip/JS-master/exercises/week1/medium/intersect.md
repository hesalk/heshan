# Intersect

Write a function `intersect` that takes two arrays as arguments. The function should return a new array that contains all the values that exists in the arrays given as arguments.

**Example**

```
intersect([1, 2, 3, 4, 5], [2, 7, 8, 5])
// -> [2, 5]
```
