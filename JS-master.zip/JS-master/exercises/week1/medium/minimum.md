# Minimum

Write a function min that takes two arguments and returns their minimum.

When you're done, modify the function to allow an unlimited amount of arguments using an array.

Then you can create a function called `maximum` that does the same as `minimum` but instead returns the max number.

*Example*
```
minimum(1, 2)
// -> 1
minimum([2, 3, 4])
// -> 2
```
