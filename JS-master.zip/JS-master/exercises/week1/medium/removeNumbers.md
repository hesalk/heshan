# Remove numbers

Write a function `removeNumbers` that takes an array as argument. Return the same array but with all numbers in it removed.

**Example**

```
removeNumbers(['hello', '2', 3, 138, 'banana'])
// -> ['hello', '2', 'banana']
```
