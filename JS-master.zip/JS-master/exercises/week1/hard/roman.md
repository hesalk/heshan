# Roman numerals

Write a function `roman` that takes a number as an argument. Then return the roman numeral representation of that number.

*Example*
```
roman(5)
// -> 'V'
roman(123)
// -> 'CXXIII'
```
