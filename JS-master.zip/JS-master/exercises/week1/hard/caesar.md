# Caesar cipher

A caesar cipher is a very simple encryption technique. It takes any letter and changes the value of it to another letter a fixed number of positions. For example (D becomes A).

Write a program that takes two arguments. The first is wheter the input should be encoded or decrypted. The second argument is the string that should be encoded or decrypted.

Then return the string with each letter replaced with a left shift of 3 (e.g D to A).

You could add a third argument that specifices the number of shifts that should be done.
