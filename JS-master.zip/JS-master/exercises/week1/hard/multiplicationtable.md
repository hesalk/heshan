# Multiplication table

Write a program that creates a multiplication table for numbers up to 12 in HTML.
