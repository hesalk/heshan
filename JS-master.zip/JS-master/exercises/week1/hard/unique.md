# Unique

Write a function `unique` that takes an array of strings as argument. Return a new array including only unique strings that exists in the given array.

*Example*
```
unique(["banana", "apple", "banana", "carrot"])
// -> ["banana", "apple", "carrot"]
```
