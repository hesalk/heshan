# Sublist

Write a function `sublist` that takes two seperate arrays as arguments. Then return if the second argument is a subarray of the first.

*Example*
```
sublist([1,2,3,4,5], [2,3])
// -> true
sublist([1,2,3,4,5], [2,6])
// -> false
```
