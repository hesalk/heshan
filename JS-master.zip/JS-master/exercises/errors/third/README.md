# Third error exercise

This one is harder and optional. But at least try it! Have fun!


## Expected results

We have multiple buttons on the site. We want so that when a button is clicked, the background color of the container should change to another value depending on the button clicked.

If the background color is changed to red, we want the color of the text to change to white. Otherwise it should be black.
