/*
 * Code should write "Hello!" to the console 10 times
 */

function test {
  console..log("Hello!');
}

for (let i = 0, i < 10, i++) {
  test; 
}
