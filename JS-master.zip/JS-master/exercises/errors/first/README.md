# First error exercise

Fix the errors that you get in the console when you open first.html

You'll know that you're done when you dont get any more errors.
